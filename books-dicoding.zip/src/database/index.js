const db = {
	books : []
}

module.exports =  db